package com.aimoverlay

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private val prefs by lazy { getSharedPreferences("aim", Context.MODE_PRIVATE) }

    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK && res.data != null) {
            val i = Intent(this, OverlayService::class.java)
                .putExtra(OverlayService.EXTRA_CODE, res.resultCode)
                .putExtra(OverlayService.EXTRA_DATA, res.data)
            startForegroundService(i)
            Toast.makeText(this, "تم التشغيل — افتح اللعبة", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "لم يتم السماح بتسجيل الشاشة", Toast.LENGTH_LONG).show()
        }
    }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL

        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String, size: Float = 16f) = TextView(this).apply {
            text = t; textSize = size; gravity = Gravity.START
            setPadding(0, pad / 2, 0, 0)
        }

        root.addView(label("خط التصويب والارتداد", 24f))
        root.addView(label("شغّل التطبيق ثم افتح اللعبة. سيظهر خط المسار فوق الطاولة ويتحرك مع العصا."))

        // عدد الارتدادات
        val bTxt = label("")
        val bSeek = SeekBar(this).apply { max = 5 }
        fun showB(v: Int) { bTxt.text = "عدد الارتدادات: $v" }
        bSeek.progress = prefs.getInt("bounces", 3) - 1
        showB(bSeek.progress + 1)
        bSeek.setOnSeekBarChangeListener(listener { p ->
            prefs.edit().putInt("bounces", p + 1).apply(); showB(p + 1)
        })
        root.addView(bTxt); root.addView(bSeek)

        // ضبط حدود الطاولة
        val aTxt = label("")
        val aSeek = SeekBar(this).apply { max = 60 }
        fun showA(v: Int) { aTxt.text = "ضبط حدود الطاولة: ${v - 30}  (إن كان الارتداد يسبق الحافة أو يتأخر عنها)" }
        aSeek.progress = prefs.getInt("adjust2", 0) + 30
        showA(aSeek.progress)
        aSeek.setOnSeekBarChangeListener(listener { p ->
            prefs.edit().putInt("adjust2", p - 30).apply(); showA(p)
        })
        root.addView(aTxt); root.addView(aSeek)

        val cb = CheckBox(this).apply {
            text = "إظهار خط الكرة البيضاء (السماوي) أيضاً"
            isChecked = prefs.getBoolean("showCue", false)
            setOnCheckedChangeListener { _, c -> prefs.edit().putBoolean("showCue", c).apply() }
        }
        root.addView(cb)

        val start = Button(this).apply {
            text = "تشغيل"
            setOnClickListener { startFlow() }
        }
        val stop = Button(this).apply {
            text = "إيقاف"
            setOnClickListener {
                startService(Intent(this@MainActivity, OverlayService::class.java)
                    .setAction(OverlayService.ACTION_STOP))
            }
        }
        root.addView(start); root.addView(stop)
        setContentView(root)
    }

    private fun listener(f: (Int) -> Unit) = object : SeekBar.OnSeekBarChangeListener {
        override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) f(p) }
        override fun onStartTrackingTouch(s: SeekBar?) {}
        override fun onStopTrackingTouch(s: SeekBar?) {}
    }

    private fun startFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات الأخرى» ثم ارجع واضغط تشغيل", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        capture.launch(mpm.createScreenCaptureIntent())
    }
}
