package com.aimoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path as GPath
import android.view.View

/** طبقة شفافة ترسم الخطة فوق اللعبة. الإحداثيات بوحدة لقطة الشاشة المصغّرة. */
class AimOverlayView(context: Context) : View(context) {

    private var plan: Plan? = null
    private var showCue = false
    private var sx = 1f
    private var sy = 1f

    // ألوان لا تلتبس على الكاشف: سماوي للكرة البيضاء، وأخضر ليموني للكرة الهدف
    private fun stroke(color: Int, w: Float) = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = w
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        this.color = color
    }

    private val cyan = Color.argb(175, 0, 255, 255)
    private val lime = Color.argb(175, 60, 255, 0)
    private val cueLine = stroke(cyan, 6f)
    private val objLine = stroke(lime, 6f)
    private val thin = stroke(Color.argb(150, 0, 255, 255), 3f)
    private val shadow = stroke(Color.argb(0, 0, 0, 0), 1f)
    private val ringCyan = stroke(cyan, 5f)
    private val ringLime = stroke(lime, 5f)
    private val fillLime = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = lime }
    private val bounceDot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(200, 255, 0, 255)
    }

    fun update(p: Plan, capW: Int, capH: Int, cue: Boolean) {
        plan = p
        showCue = cue
        sx = width.toFloat() / capW
        sy = height.toFloat() / capH
        invalidate()
    }

    fun clear() {
        if (plan != null) {
            plan = null
            invalidate()
        }
    }

    private fun path(pts: List<FloatArray>): GPath {
        val g = GPath()
        g.moveTo(pts[0][0] * sx, pts[0][1] * sy)
        for (i in 1 until pts.size) g.lineTo(pts[i][0] * sx, pts[i][1] * sy)
        return g
    }

    override fun onDraw(canvas: Canvas) {
        val p = plan ?: return
        val rad = p.radius * sx

        if (showCue) {
            if (p.cue.size >= 2) {
                val g = path(p.cue)
                canvas.drawPath(g, cueLine)
                for (i in 1 until p.cue.size - 1) canvas.drawCircle(p.cue[i][0] * sx, p.cue[i][1] * sy, 7f, bounceDot)
            }
            canvas.drawCircle(p.ring[0] * sx, p.ring[1] * sy, rad, ringCyan)
            p.deflect?.let { canvas.drawPath(path(it), thin) }
        }
        p.obj?.let {
            val g = path(it)
            canvas.drawPath(g, objLine)
            val e = it.last()
            if (p.potted) canvas.drawCircle(e[0] * sx, e[1] * sy, rad * 0.8f, fillLime)
            else canvas.drawCircle(e[0] * sx, e[1] * sy, rad, ringLime)
        }
    }
}
