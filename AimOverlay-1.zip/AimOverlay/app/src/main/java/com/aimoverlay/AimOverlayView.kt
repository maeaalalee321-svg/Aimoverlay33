package com.aimoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path as GPath
import android.view.View

/** طبقة شفافة ترسم المسار فوق اللعبة. الإحداثيات تأتي بوحدة لقطة الشاشة المصغّرة. */
class AimOverlayView(context: Context) : View(context) {

    private var pts: List<FloatArray> = emptyList()
    private var ballR = 0f
    private var sx = 1f
    private var sy = 1f

    // نستعمل السماوي: ليس أبيض ولا خشبياً، فلا تلتبس الطبقة على الكاشف حين تلتقط الشاشة
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.rgb(0, 255, 255)
    }
    private val outline = Paint(line).apply {
        strokeWidth = 9f
        color = Color.argb(150, 0, 0, 0)
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 5f
        color = Color.rgb(0, 255, 255)
    }
    private val bounceDot = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.rgb(255, 0, 255)
    }

    fun update(points: List<FloatArray>, radius: Float, capW: Int, capH: Int) {
        pts = points
        ballR = radius
        sx = width.toFloat() / capW
        sy = height.toFloat() / capH
        invalidate()
    }

    fun clear() {
        if (pts.isNotEmpty()) {
            pts = emptyList()
            invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        if (pts.size < 2) return
        val p = GPath()
        p.moveTo(pts[0][0] * sx, pts[0][1] * sy)
        for (i in 1 until pts.size) p.lineTo(pts[i][0] * sx, pts[i][1] * sy)
        canvas.drawPath(p, outline)
        canvas.drawPath(p, line)

        // نقاط الارتداد
        for (i in 1 until pts.size - 1) canvas.drawCircle(pts[i][0] * sx, pts[i][1] * sy, 7f, bounceDot)

        // الدائرة في نهاية المسار
        val e = pts.last()
        canvas.drawCircle(e[0] * sx, e[1] * sy, ballR * sx, ring)
    }
}
