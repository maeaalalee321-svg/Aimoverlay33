package com.aimoverlay

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** حدود الطاولة (مركز الكرة يرتد عند هذه الحدود بعد طرح نصف القطر). */
data class TableBox(val l: Float, val t: Float, val r: Float, val b: Float)

/**
 * نتيجة الكشف (كل الإحداثيات بوحدة بكسل لقطة الشاشة المصغّرة).
 * @param gameLineLen طول الخط الأبيض الذي ترسمه اللعبة نفسها (إن وُجد)
 */
data class Detection(
    val bx: Float,
    val by: Float,
    val angle: Float,       // بالراديان، اتجاه الضربة (عكس اتجاه العصا)
    val radius: Float,      // نصف قطر الكرة
    val gameLineLen: Float,
    val table: TableBox,
    val tableW: Float
)

/**
 * يعمل على مصفوفة بكسلات ARGB. يكتشف: الطاولة (اللون الأخضر) ثم الكرة البيضاء
 * ثم اتجاه العصا (لون خشبي خلف الكرة) وخط التصويب الأبيض الذي ترسمه اللعبة.
 */
class Detector {

    private fun isFelt(c: Int): Boolean {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return g > r + 20 && g > b + 20 && g > 70
    }

    private fun isWhite(c: Int): Boolean {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return r > 195 && g > 195 && b > 195 && abs(r - g) < 30 && abs(g - b) < 30
    }

    /** لون عصا خشبي (بني فاتح/ذهبي) وليس أخضر ولا أبيض. */
    private fun isStick(c: Int): Boolean {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return r > 120 && r > g + 15 && g > b + 10
    }

    /** أطول مقطع متصل (مع السماح بفجوات) في مصفوفة قيم، يرجع [بداية، نهاية] أو null. */
    private inline fun longestRun(n: Int, gap: Int, test: (Int) -> Boolean): IntArray? {
        var start = -1
        var last = -1
        var bestLen = 0
        var bs = 0
        var be = 0
        for (i in 0 until n) {
            if (test(i)) {
                if (start < 0) start = i
                else if (i - last > gap) {
                    if (last - start > bestLen) { bestLen = last - start; bs = start; be = last }
                    start = i
                }
                last = i
            }
        }
        if (start >= 0 && last - start > bestLen) { bestLen = last - start; bs = start; be = last }
        return if (bestLen > 0) intArrayOf(bs, be) else null
    }

    private fun median(v: MutableList<Int>): Float {
        v.sort()
        return v[v.size / 2].toFloat()
    }

    private fun findTable(px: IntArray, w: Int, h: Int): FloatArray? {
        val lefts = ArrayList<Int>()
        val rights = ArrayList<Int>()
        val gapX = (w * 0.03f).toInt().coerceAtLeast(2)
        var y = (h * 0.35f).toInt()
        val yEnd = (h * 0.75f).toInt()
        while (y < yEnd) {
            val row = y * w
            val run = longestRun(w, gapX) { x -> isFelt(px[row + x]) }
            if (run != null && run[1] - run[0] > w * 0.4f) {
                lefts.add(run[0]); rights.add(run[1])
            }
            y += 3
        }
        if (lefts.size < 8) return null
        val l = median(lefts)
        val r = median(rights)
        val tw = r - l
        val tops = ArrayList<Int>()
        val bots = ArrayList<Int>()
        val gapY = (h * 0.05f).toInt().coerceAtLeast(2)
        var x = (l + tw * 0.15f).toInt()
        val xEnd = (l + tw * 0.85f).toInt()
        while (x < xEnd) {
            val run = longestRun(h, gapY) { yy -> isFelt(px[yy * w + x]) }
            if (run != null && run[1] - run[0] > h * 0.4f) {
                tops.add(run[0]); bots.add(run[1])
            }
            x += 4
        }
        if (tops.size < 8) return null
        return floatArrayOf(l, median(tops), r, median(bots))
    }

    /** يكتشف الكرة البيضاء بأقصى كثافة بيضاء داخل نافذة بحجم الكرة. */
    private fun findCueBall(px: IntArray, w: Int, h: Int, box: FloatArray, r: Float): FloatArray? {
        val k = max(2, (r * 0.9f).toInt())
        val x0 = max(box[0].toInt() + k + 1, k + 1)
        val x1 = min(box[2].toInt() - k - 1, w - k - 2)
        val y0 = max(box[1].toInt() + k + 1, k + 1)
        val y1 = min(box[3].toInt() - k - 1, h - k - 2)
        if (x1 <= x0 || y1 <= y0) return null

        // صورة تكاملية للقناع الأبيض داخل منطقة الطاولة
        val iw = w + 1
        val integ = IntArray(iw * (h + 1))
        for (y in 0 until h) {
            var rowSum = 0
            for (x in 0 until w) {
                if (isWhite(px[y * w + x])) rowSum++
                integ[(y + 1) * iw + (x + 1)] = integ[y * iw + (x + 1)] + rowSum
            }
        }
        var best = -1
        var bx = 0
        var by = 0
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val a = integ[(y - k) * iw + (x - k)]
                val b = integ[(y - k) * iw + (x + k + 1)]
                val c = integ[(y + k + 1) * iw + (x - k)]
                val d = integ[(y + k + 1) * iw + (x + k + 1)]
                val s = d - b - c + a
                if (s > best) { best = s; bx = x; by = y }
                x += 2
            }
            y += 2
        }
        val side = 2 * k + 1
        if (best < side * side * 0.5f) return null

        // تحسين المركز: متوسط البكسلات البيضاء القريبة
        var cx = bx.toFloat()
        var cy = by.toFloat()
        repeat(3) {
            var sx = 0f; var sy = 0f; var n = 0
            val rr = r * 1.1f
            val ya = max(0, (cy - rr).toInt()); val yb = min(h - 1, (cy + rr).toInt())
            val xa = max(0, (cx - rr).toInt()); val xb = min(w - 1, (cx + rr).toInt())
            for (yy in ya..yb) for (xx in xa..xb) {
                val dx = xx - cx; val dy = yy - cy
                if (dx * dx + dy * dy <= rr * rr && isWhite(px[yy * w + xx])) { sx += xx; sy += yy; n++ }
            }
            if (n > 0) { cx = sx / n; cy = sy / n }
        }
        return floatArrayOf(cx, cy)
    }

    fun detect(px: IntArray, w: Int, h: Int): Detection? {
        val tb = findTable(px, w, h) ?: return null
        val tw = tb[2] - tb[0]
        if (tw < w * 0.4f) return null
        val r = tw * 0.0136f
        val ball = findCueBall(px, w, h, tb, r) ?: return null
        val cx = ball[0]
        val cy = ball[1]

        val maxWhite = tw * 0.9f
        val maxStick = tw * 0.6f
        val steps = 900                      // 0.4 درجة لكل خطوة
        val score = FloatArray(steps)
        val whiteLen = FloatArray(steps)

        for (i in 0 until steps) {
            val a = (i * 2.0 * Math.PI / steps)
            val dx = cos(a).toFloat()
            val dy = sin(a).toFloat()

            // خط التصويب الأبيض أمام الكرة
            var d = r * 1.5f
            var miss = 0
            var lastHit = d
            while (d < maxWhite) {
                val xx = cx + dx * d
                val yy = cy + dy * d
                var hit = false
                for (o in -1..1) {
                    val px2 = (xx - dy * o + 0.5f).toInt()
                    val py2 = (yy + dx * o + 0.5f).toInt()
                    if (px2 in 0 until w && py2 in 0 until h && isWhite(px[py2 * w + px2])) { hit = true; break }
                }
                if (hit) { miss = 0; lastHit = d } else { miss++; if (miss > 3) break }
                d += 1f
            }
            val wl = lastHit - r * 1.5f

            // العصا خلف الكرة
            var sCount = 0
            d = r * 1.4f
            while (d < maxStick) {
                val xx = (cx - dx * d + 0.5f).toInt()
                val yy = (cy - dy * d + 0.5f).toInt()
                if (xx in 0 until w && yy in 0 until h && isStick(px[yy * w + xx])) sCount++
                d += 1.5f
            }
            whiteLen[i] = wl
            score[i] = wl + sCount * 1.5f
        }

        var bi = 0
        for (i in 1 until steps) if (score[i] > score[bi]) bi = i
        val best = score[bi]
        if (best < r * 6f) return null       // لا توجد عصا / لا يوجد تصويب

        // متوسط الزوايا القريبة من الأفضل لدقة أعلى
        var sx = 0.0
        var sy = 0.0
        var wlSum = 0f
        var n = 0
        for (i in 0 until steps) {
            if (score[i] >= best * 0.97f) {
                val a = i * 2.0 * Math.PI / steps
                sx += cos(a); sy += sin(a)
                wlSum += whiteLen[i]; n++
            }
        }
        val ang = atan2(sy, sx).toFloat()
        return Detection(cx, cy, ang, r, wlSum / max(n, 1), TableBox(tb[0], tb[1], tb[2], tb[3]), tw)
    }
}
