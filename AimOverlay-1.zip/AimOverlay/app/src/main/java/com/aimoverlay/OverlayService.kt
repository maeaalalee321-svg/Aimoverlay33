package com.aimoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.aimoverlay.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        private const val CHANNEL = "aim"
        private const val SCALE = 2          // نصغّر اللقطة للنصف لسرعة المعالجة
        private const val MIN_INTERVAL_MS = 60L
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: AimOverlayView? = null
    private lateinit var wm: WindowManager
    private val detector = Detector()
    private lateinit var thread: HandlerThread
    private lateinit var bg: Handler
    private val main = Handler(Looper.getMainLooper())
    private var lastRun = 0L
    private var capW = 0
    private var capH = 0
    private var px = IntArray(0)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (projection != null) return START_NOT_STICKY

        startAsForeground()

        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33)
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        else
            @Suppress("DEPRECATION") intent?.getParcelableExtra(EXTRA_DATA)
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        thread = HandlerThread("aim-detect").also { it.start() }
        bg = Handler(thread.looper)

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data).also {
            // أندرويد 14 يشترط تسجيل callback قبل إنشاء الشاشة الافتراضية
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    main.post { stopSelf() }
                }
            }, main)
        }

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        addOverlay()
        setupCapture()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "خط التصويب", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("خط التصويب يعمل")
            .setContentText("اضغط إيقاف لإغلاقه")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_delete, "إيقاف", stop).build())
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else
            startForeground(1, n)
    }

    private fun addOverlay() {
        val v = AimOverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 28)
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        wm.addView(v, lp)
        overlay = v
    }

    @Suppress("DEPRECATION")
    private fun realSize(): IntArray {
        val m = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(m)
        return intArrayOf(m.widthPixels, m.heightPixels, m.densityDpi)
    }

    private fun setupCapture() {
        val s = realSize()
        capW = s[0] / SCALE
        capH = s[1] / SCALE
        px = IntArray(capW * capH)

        reader?.close()
        val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        reader = r
        r.setOnImageAvailableListener({ ir -> onFrame(ir) }, bg)

        val d = display
        if (d == null) {
            display = projection!!.createVirtualDisplay(
                "aim", capW, capH, s[2],
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.surface, null, null
            )
        } else {
            d.resize(capW, capH, s[2])
            d.surface = r.surface
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (projection != null) main.post { setupCapture() }   // تدوير الشاشة
    }

    private fun onFrame(ir: ImageReader) {
        val img = try { ir.acquireLatestImage() } catch (e: Exception) { null } ?: return
        try {
          try {
            val now = System.currentTimeMillis()
            if (now - lastRun < MIN_INTERVAL_MS) return
            lastRun = now

            val w = img.width
            val h = img.height
            if (w != capW || h != capH) return
            val plane = img.planes[0]
            val buf = plane.buffer
            val rowStride = plane.rowStride
            val pxStride = plane.pixelStride
            for (y in 0 until h) {
                var o = y * rowStride
                val base = y * w
                for (x in 0 until w) {
                    val r = buf.get(o).toInt() and 255
                    val g = buf.get(o + 1).toInt() and 255
                    val b = buf.get(o + 2).toInt() and 255
                    px[base + x] = (r shl 16) or (g shl 8) or b
                    o += pxStride
                }
            }

            val prefs = getSharedPreferences("aim", MODE_PRIVATE)
            val bounces = prefs.getInt("bounces", 3)
            val adjust = prefs.getInt("adjust", 0)          // بوحدة 0.1% من عرض الطاولة
            val stopAtBall = prefs.getBoolean("stopAtBall", false)

            val det = detector.detect(px, w, h)
            if (det == null) {
                main.post { overlay?.clear() }
                return
            }
            val inset = adjust * 0.001f * det.tableW
            val path = Trajectory.compute(det, inset, bounces, stopAtBall)
            val r = det.radius
            main.post { overlay?.update(path.points, r, w, h) }
          } catch (e: Exception) {
            // إطار تالف أو تغيّر الحجم أثناء المعالجة: نتجاهله
          }
        } finally {
            img.close()
        }
    }

    override fun onDestroy() {
        reader?.setOnImageAvailableListener(null, null)
        display?.release()
        reader?.close()
        projection?.stop()
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        if (::thread.isInitialized) thread.quitSafely()
        super.onDestroy()
    }
}
