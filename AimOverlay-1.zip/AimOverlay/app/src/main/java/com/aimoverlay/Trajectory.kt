package com.aimoverlay

import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

data class Path(
    val points: List<FloatArray>,   // نقاط المسار (x,y)
    val endsOnBall: Boolean         // انتهى عند ملامسة كرة (وليس بسبب عدد الارتدادات)
)

object Trajectory {

    /**
     * يحسب مسار الكرة البيضاء مع الارتداد عن الحواف.
     * @param contactDist مسافة أول ملامسة لكرة (من الخط الأبيض للّعبة) أو سالب إن لم توجد
     */
    fun compute(
        d: Detection,
        inset: Float,
        maxBounces: Int,
        stopAtBall: Boolean
    ): Path {
        val r = d.radius
        val box = TableBox(
            d.table.l + r + inset,
            d.table.t + r + inset,
            d.table.r - r - inset,
            d.table.b - r - inset
        )
        var x = d.bx
        var y = d.by
        var dx = cos(d.angle)
        var dy = sin(d.angle)
        val pts = ArrayList<FloatArray>()
        pts.add(floatArrayOf(x, y))

        var firstSegment = true
        var travelled = 0f
        val maxTotal = d.tableW * 6f
        var bounces = 0
        while (bounces <= maxBounces) {
            val tx = when {
                dx > 1e-6f -> (box.r - x) / dx
                dx < -1e-6f -> (box.l - x) / dx
                else -> Float.MAX_VALUE
            }
            val ty = when {
                dy > 1e-6f -> (box.b - y) / dy
                dy < -1e-6f -> (box.t - y) / dy
                else -> Float.MAX_VALUE
            }
            var t = minOf(tx, ty)
            if (t < 0f) t = 0f

            // لامست الكرة قبل الحافة؟ (الخط الأبيض للّعبة انتهى مبكراً)
            if (firstSegment && stopAtBall && d.gameLineLen > r * 3f && d.gameLineLen < t - r * 1.5f) {
                val c = d.gameLineLen
                pts.add(floatArrayOf(x + dx * c, y + dy * c))
                return Path(pts, true)
            }
            firstSegment = false

            if (travelled + t > maxTotal) {
                val rest = maxTotal - travelled
                pts.add(floatArrayOf(x + dx * rest, y + dy * rest))
                return Path(pts, false)
            }
            x += dx * t
            y += dy * t
            travelled += t
            pts.add(floatArrayOf(x, y))

            if (bounces == maxBounces) break
            if (tx <= ty) dx = -dx else dy = -dy
            if (hypot(dx, dy) < 1e-6f) break
            bounces++
        }
        return Path(pts, false)
    }
}
