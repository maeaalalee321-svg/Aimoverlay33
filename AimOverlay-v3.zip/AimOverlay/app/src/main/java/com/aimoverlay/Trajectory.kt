package com.aimoverlay

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * خطة الرسم:
 *  cue      مسار الكرة البيضاء (مع الارتداد إن لم تلامس كرة)
 *  ring     مركز الدائرة التي تُرسم في نهاية المسار (الكرة الشبحية أو نهاية الارتداد)
 *  deflect  اتجاه الكرة البيضاء بعد الاصطدام بكرة
 *  obj      مسار الكرة الهدف
 *  potted   هل الكرة الهدف تدخل جيباً
 */
class Plan(
    val cue: List<FloatArray>,
    val ring: FloatArray,
    val deflect: List<FloatArray>?,
    val obj: List<FloatArray>?,
    val potted: Boolean,
    val radius: Float
)

object Trajectory {

    fun compute(d: Detection, inset: Float, maxBounces: Int, showObject: Boolean): Plan {
        val r = d.radius
        val raw = d.table
        val box = TableBox(raw.l + r + inset, raw.t + r + inset, raw.r - r - inset, raw.b - r - inset)
        val ux = cos(d.angle)
        val uy = sin(d.angle)

        val c = d.contact
        if (showObject && c != null) {
            val cue = listOf(floatArrayOf(d.bx, d.by), floatArrayOf(c.gx, c.gy))

            // اتجاه الكرة البيضاء بعد الاصطدام: المركبة العمودية على خط التماس
            val dot = ux * c.nx + uy * c.ny
            var tx = ux - c.nx * dot
            var ty = uy - c.ny * dot
            val tl = hypot(tx, ty)
            var deflect: List<FloatArray>? = null
            if (tl > 0.15f) {
                tx /= tl; ty /= tl
                val len = r * (3f + 5f * tl)
                deflect = listOf(floatArrayOf(c.gx, c.gy), floatArrayOf(c.gx + tx * len, c.gy + ty * len))
            }

            // مسار الكرة الهدف: إلى أول حافة أو جيب
            val (path, potted) = objectPath(c.ox, c.oy, c.nx, c.ny, box, raw, r)
            return Plan(cue, floatArrayOf(c.gx, c.gy), deflect, path, potted, r)
        }
        return Plan(bouncePath(d.bx, d.by, ux, uy, box, maxBounces, d.tableW * 6f),
            lastPoint(d, box, maxBounces), null, null, false, r)
    }

    private fun lastPoint(d: Detection, box: TableBox, n: Int): FloatArray {
        val p = bouncePath(d.bx, d.by, cos(d.angle), sin(d.angle), box, n, d.tableW * 6f)
        return p.last()
    }

    private fun bouncePath(
        sx: Float, sy: Float, ux: Float, uy: Float,
        box: TableBox, maxBounces: Int, maxTotal: Float
    ): List<FloatArray> {
        var x = sx
        var y = sy
        var dx = ux
        var dy = uy
        val pts = ArrayList<FloatArray>()
        pts.add(floatArrayOf(x, y))
        var travelled = 0f
        var bounces = 0
        while (true) {
            val tx = when {
                dx > 1e-6f -> (box.r - x) / dx
                dx < -1e-6f -> (box.l - x) / dx
                else -> Float.MAX_VALUE
            }
            val ty = when {
                dy > 1e-6f -> (box.b - y) / dy
                dy < -1e-6f -> (box.t - y) / dy
                else -> Float.MAX_VALUE
            }
            var t = minOf(tx, ty)
            if (t < 0f) t = 0f
            if (travelled + t > maxTotal) {
                val rest = maxTotal - travelled
                pts.add(floatArrayOf(x + dx * rest, y + dy * rest))
                break
            }
            x += dx * t
            y += dy * t
            travelled += t
            pts.add(floatArrayOf(x, y))
            if (bounces == maxBounces) break
            if (tx <= ty) dx = -dx else dy = -dy
            bounces++
        }
        return pts
    }

    private fun objectPath(
        ox: Float, oy: Float, nx: Float, ny: Float,
        box: TableBox, raw: TableBox, r: Float
    ): Pair<List<FloatArray>, Boolean> {
        val tx = when {
            nx > 1e-6f -> (box.r - ox) / nx
            nx < -1e-6f -> (box.l - ox) / nx
            else -> Float.MAX_VALUE
        }
        val ty = when {
            ny > 1e-6f -> (box.b - oy) / ny
            ny < -1e-6f -> (box.t - oy) / ny
            else -> Float.MAX_VALUE
        }
        val tWall = maxOf(0f, minOf(tx, ty))

        // الجيوب: أربع زوايا + منتصف الحافتين الطويلتين
        val midX = (raw.l + raw.r) / 2f
        val pockets = arrayOf(
            floatArrayOf(raw.l, raw.t, 2.3f * r), floatArrayOf(raw.r, raw.t, 2.3f * r),
            floatArrayOf(raw.l, raw.b, 2.3f * r), floatArrayOf(raw.r, raw.b, 2.3f * r),
            floatArrayOf(midX, raw.t, 1.8f * r), floatArrayOf(midX, raw.b, 1.8f * r)
        )
        var bestT = Float.MAX_VALUE
        var bx = 0f
        var by = 0f
        for (p in pockets) {
            val vx = p[0] - ox
            val vy = p[1] - oy
            val along = vx * nx + vy * ny
            val perp = abs(vx * ny - vy * nx)
            if (along > 0f && perp < p[2] && along < bestT) {
                bestT = along; bx = p[0]; by = p[1]
            }
        }
        val pts = ArrayList<FloatArray>()
        pts.add(floatArrayOf(ox, oy))
        if (bestT < tWall + 3f * r) {
            pts.add(floatArrayOf(bx, by))
            return Pair(pts, true)
        }
        pts.add(floatArrayOf(ox + nx * tWall, oy + ny * tWall))
        return Pair(pts, false)
    }
}
