package com.aimoverlay

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** حدود الطاولة (مركز الكرة يرتد عند هذه الحدود بعد طرح نصف القطر). */
data class TableBox(val l: Float, val t: Float, val r: Float, val b: Float)

/**
 * نتيجة الكشف (كل الإحداثيات بوحدة بكسل لقطة الشاشة المصغّرة).
 * @param gameLineLen طول الخط الأبيض الذي ترسمه اللعبة نفسها (إن وُجد)
 */
/** ملامسة الكرة البيضاء لكرة أخرى: مركز الكرة الهدف، ومركز الكرة الشبحية عند التصادم، واتجاه الكرة الهدف. */
data class Contact(
    val ox: Float, val oy: Float,     // مركز الكرة الهدف
    val gx: Float, val gy: Float,     // مركز الكرة البيضاء لحظة التصادم
    val nx: Float, val ny: Float      // اتجاه الكرة الهدف بعد الضربة (وحدة)
)

data class Detection(
    val bx: Float,
    val by: Float,
    val angle: Float,       // بالراديان، اتجاه الضربة (عكس اتجاه العصا)
    val radius: Float,      // نصف قطر الكرة
    val gameLineLen: Float,
    val table: TableBox,
    val tableW: Float,
    val contact: Contact?
)

/**
 * يعمل على مصفوفة بكسلات ARGB. يكتشف: الطاولة (اللون الأخضر) ثم الكرة البيضاء
 * ثم اتجاه العصا (لون خشبي خلف الكرة) وخط التصويب الأبيض الذي ترسمه اللعبة.
 */
class Detector {

    /** مقاطع الرسم السابقة (x1,y1,x2,y2,...) تُستثنى من كشف الكرة حتى لا يلتقط التطبيق رسمَه هو. */
    @Volatile
    var exclusions: FloatArray = FloatArray(0)

    private fun nearExcl(x: Float, y: Float): Boolean {
        val e = exclusions
        var i = 0
        while (i + 3 < e.size) {
            val ax = e[i]; val ay = e[i + 1]; val bx = e[i + 2]; val by = e[i + 3]
            val vx = bx - ax; val vy = by - ay
            val l2 = vx * vx + vy * vy
            var t = if (l2 > 1e-6f) ((x - ax) * vx + (y - ay) * vy) / l2 else 0f
            if (t < 0f) t = 0f else if (t > 1f) t = 1f
            val px = ax + vx * t - x
            val py = ay + vy * t - y
            if (px * px + py * py < 30f) return true     // أقل من ~5.5 بكسل
            i += 4
        }
        return false
    }

    // لون قماش الطاولة يُستنتج تلقائياً (اللون الأكثر تكراراً في وسط الشاشة)، فيعمل مع أي ثيم
    private var fr = 0f
    private var fg = 0f
    private var fb = 0f
    private var fsum = 1f

    private fun estimateFelt(px: IntArray, w: Int, h: Int): Boolean {
        val cnt = IntArray(4096)
        val sr = LongArray(4096)
        val sg = LongArray(4096)
        val sb = LongArray(4096)
        var y = (h * 0.3f).toInt()
        val y1 = (h * 0.7f).toInt()
        val x0 = (w * 0.25f).toInt()
        val x1 = (w * 0.75f).toInt()
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val c = px[y * w + x]
                val r = (c shr 16) and 255
                val g = (c shr 8) and 255
                val b = c and 255
                val k = ((r shr 4) shl 8) or ((g shr 4) shl 4) or (b shr 4)
                cnt[k]++; sr[k] += r.toLong(); sg[k] += g.toLong(); sb[k] += b.toLong()
                x += 3
            }
            y += 3
        }
        var bk = 0
        for (k in 1 until 4096) if (cnt[k] > cnt[bk]) bk = k
        if (cnt[bk] < 50) return false
        fr = sr[bk].toFloat() / cnt[bk]
        fg = sg[bk].toFloat() / cnt[bk]
        fb = sb[bk].toFloat() / cnt[bk]
        fsum = fr + fg + fb + 1f
        return true
    }

    private fun isFelt(c: Int): Boolean {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        val s = (r + g + b + 1).toFloat()
        if (s < 0.45f * fsum || s > 2.2f * fsum) return false
        val dr = abs(r / s - fr / fsum)
        val dg = abs(g / s - fg / fsum)
        val db = abs(b / s - fb / fsum)
        return dr < 0.07f && dg < 0.07f && db < 0.07f
    }

    /** بكسل ينتمي لكرة ملوّنة: ليس قماشاً ولا أبيض (الخط/الحلقة). الكرة السوداء مشمولة. */
    private fun isBallPixel(c: Int): Boolean {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        val s = (r + g + b + 1).toFloat()
        if (isWhite(c)) return false
        if (s < 45f) return true                      // بكسل شبه أسود (الكرة 8)
        val dr = abs(r / s - fr / fsum)
        val dg = abs(g / s - fg / fsum)
        val db = abs(b / s - fb / fsum)
        return !(dr < 0.07f && dg < 0.07f && db < 0.07f)
    }

    /** يبحث عن الكرة التي يلامسها خط التصويب قرب (gx,gy) ويحسب اتجاهها بعد التصادم. */
    private fun findContact(
        px: IntArray, w: Int, h: Int, tb: FloatArray, r: Float,
        gx: Float, gy: Float, bx: Float, by: Float, dx: Float, dy: Float
    ): Contact? {
        val ya = max(max(0, (gy - 3f * r).toInt()), tb[1].toInt())
        val yb = min(min(h - 1, (gy + 3f * r).toInt()), tb[3].toInt())
        val xa = max(max(0, (gx - 3f * r).toInt()), tb[0].toInt())
        val xb = min(min(w - 1, (gx + 3f * r).toInt()), tb[2].toInt())
        var sx = 0f; var sy = 0f; var n = 0
        for (y in ya..yb) for (x in xa..xb) {
            val ddx = x - gx; val ddy = y - gy
            val d2 = ddx * ddx + ddy * ddy
            if (d2 >= (1.4f * r) * (1.4f * r) && d2 <= 9f * r * r && isBallPixel(px[y * w + x]) &&
                !nearExcl(x.toFloat(), y.toFloat())) {
                sx += x; sy += y; n++
            }
        }
        val area = Math.PI.toFloat() * r * r
        if (n < 0.35f * area) return null
        var cx = sx / n
        var cy = sy / n
        var cnt = 0
        repeat(4) {
            var ax = 0f; var ay = 0f; var k = 0
            val rr = r * 1.15f
            val y0 = max(max(0, (cy - rr).toInt()), tb[1].toInt())
            val y1 = min(min(h - 1, (cy + rr).toInt()), tb[3].toInt())
            val x0 = max(max(0, (cx - rr).toInt()), tb[0].toInt())
            val x1 = min(min(w - 1, (cx + rr).toInt()), tb[2].toInt())
            for (y in y0..y1) for (x in x0..x1) {
                val ddx = x - cx; val ddy = y - cy
                if (ddx * ddx + ddy * ddy <= rr * rr && isBallPixel(px[y * w + x]) &&
                    !nearExcl(x.toFloat(), y.toFloat())) { ax += x; ay += y; k++ }
            }
            cnt = k
            if (k >= 5) { cx = ax / k; cy = ay / k }
        }
        if (cnt < 0.5f * area) return null

        // هندسة التصادم: نقطة على خط التصويب تبعد 2r عن مركز الكرة الهدف
        val proj = (cx - bx) * dx + (cy - by) * dy
        val perp = abs(-(cx - bx) * dy + (cy - by) * dx)
        if (perp >= 2f * r) return null
        val t = proj - kotlin.math.sqrt(4f * r * r - perp * perp)
        if (t <= 0f) return null
        val g2x = bx + dx * t
        val g2y = by + dy * t
        return Contact(cx, cy, g2x, g2y, (cx - g2x) / (2f * r), (cy - g2y) / (2f * r))
    }

    private fun isWhite(c: Int): Boolean {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return r > 195 && g > 195 && b > 195 && abs(r - g) < 30 && abs(g - b) < 30
    }

    /** أطول مقطع متصل (مع السماح بفجوات) في مصفوفة قيم، يرجع [بداية، نهاية] أو null. */
    private inline fun longestRun(n: Int, gap: Int, test: (Int) -> Boolean): IntArray? {
        var start = -1
        var last = -1
        var bestLen = 0
        var bs = 0
        var be = 0
        for (i in 0 until n) {
            if (test(i)) {
                if (start < 0) start = i
                else if (i - last > gap) {
                    if (last - start > bestLen) { bestLen = last - start; bs = start; be = last }
                    start = i
                }
                last = i
            }
        }
        if (start >= 0 && last - start > bestLen) { bestLen = last - start; bs = start; be = last }
        return if (bestLen > 0) intArrayOf(bs, be) else null
    }

    private fun median(v: MutableList<Int>): Float {
        v.sort()
        return v[v.size / 2].toFloat()
    }

    private fun findTable(px: IntArray, w: Int, h: Int): FloatArray? {
        if (!estimateFelt(px, w, h)) return null
        val lefts = ArrayList<Int>()
        val rights = ArrayList<Int>()
        val gapX = (w * 0.03f).toInt().coerceAtLeast(2)
        var y = (h * 0.35f).toInt()
        val yEnd = (h * 0.75f).toInt()
        while (y < yEnd) {
            val row = y * w
            val run = longestRun(w, gapX) { x -> isFelt(px[row + x]) }
            if (run != null && run[1] - run[0] > w * 0.4f) {
                lefts.add(run[0]); rights.add(run[1])
            }
            y += 3
        }
        if (lefts.size < 8) return null
        val l = median(lefts)
        val r = median(rights)
        val tw = r - l
        val tops = ArrayList<Int>()
        val bots = ArrayList<Int>()
        val gapY = (h * 0.05f).toInt().coerceAtLeast(2)
        var x = (l + tw * 0.15f).toInt()
        val xEnd = (l + tw * 0.85f).toInt()
        while (x < xEnd) {
            val run = longestRun(h, gapY) { yy -> isFelt(px[yy * w + x]) }
            if (run != null && run[1] - run[0] > h * 0.4f) {
                tops.add(run[0]); bots.add(run[1])
            }
            x += 4
        }
        if (tops.size < 8) return null
        // نسبة الطاولة ثابتة تقريباً؛ نصحح الحافة العلوية إن التبست بزخرفة الإطار
        val expectedH = tw * 0.521f
        val bot = median(bots)
        var top = median(tops)
        if (abs((bot - top) - expectedH) > 0.05f * expectedH) top = bot - expectedH
        return floatArrayOf(l, top, r, bot)
    }

    /** يكتشف الكرة البيضاء بأقصى كثافة بيضاء داخل نافذة بحجم الكرة. */
    private fun findCueBall(px: IntArray, w: Int, h: Int, box: FloatArray, r: Float): FloatArray? {
        val k = max(2, (r * 0.9f).toInt())
        val x0 = max(box[0].toInt() + k + 1, k + 1)
        val x1 = min(box[2].toInt() - k - 1, w - k - 2)
        val y0 = max(box[1].toInt() + k + 1, k + 1)
        val y1 = min(box[3].toInt() - k - 1, h - k - 2)
        if (x1 <= x0 || y1 <= y0) return null

        // صورة تكاملية للقناع الأبيض داخل منطقة الطاولة
        val iw = w + 1
        val integ = IntArray(iw * (h + 1))
        for (y in 0 until h) {
            var rowSum = 0
            for (x in 0 until w) {
                if (isWhite(px[y * w + x])) rowSum++
                integ[(y + 1) * iw + (x + 1)] = integ[y * iw + (x + 1)] + rowSum
            }
        }
        var best = -1
        var bx = 0
        var by = 0
        var y = y0
        while (y < y1) {
            var x = x0
            while (x < x1) {
                val a = integ[(y - k) * iw + (x - k)]
                val b = integ[(y - k) * iw + (x + k + 1)]
                val c = integ[(y + k + 1) * iw + (x - k)]
                val d = integ[(y + k + 1) * iw + (x + k + 1)]
                val s = d - b - c + a
                if (s > best) { best = s; bx = x; by = y }
                x += 2
            }
            y += 2
        }
        val side = 2 * k + 1
        if (best < side * side * 0.5f) return null

        // تحسين المركز: متوسط البكسلات البيضاء القريبة
        var cx = bx.toFloat()
        var cy = by.toFloat()
        repeat(3) {
            var sx = 0f; var sy = 0f; var n = 0
            val rr = r * 1.1f
            val ya = max(0, (cy - rr).toInt()); val yb = min(h - 1, (cy + rr).toInt())
            val xa = max(0, (cx - rr).toInt()); val xb = min(w - 1, (cx + rr).toInt())
            for (yy in ya..yb) for (xx in xa..xb) {
                val dx = xx - cx; val dy = yy - cy
                if (dx * dx + dy * dy <= rr * rr && isWhite(px[yy * w + xx])) { sx += xx; sy += yy; n++ }
            }
            if (n > 0) { cx = sx / n; cy = sy / n }
        }
        return floatArrayOf(cx, cy)
    }

    fun detect(px: IntArray, w: Int, h: Int): Detection? {
        val tb = findTable(px, w, h) ?: return null
        val tw = tb[2] - tb[0]
        if (tw < w * 0.4f) return null
        val r = tw * 0.0136f
        val ball = findCueBall(px, w, h, tb, r) ?: return null
        val cx = ball[0]
        val cy = ball[1]

        val maxWhite = tw * 0.9f
        val steps = 900                      // 0.4 درجة لكل خطوة
        val score = FloatArray(steps)
        val whiteLen = FloatArray(steps)

        for (i in 0 until steps) {
            val a = (i * 2.0 * Math.PI / steps)
            val dx = cos(a).toFloat()
            val dy = sin(a).toFloat()

            // خط التصويب الأبيض أمام الكرة
            var d = r * 1.5f
            var miss = 0
            var lastHit = d
            while (d < maxWhite) {
                val xx = cx + dx * d
                val yy = cy + dy * d
                var hit = false
                for (o in -1..1) {
                    val px2 = (xx - dy * o + 0.5f).toInt()
                    val py2 = (yy + dx * o + 0.5f).toInt()
                    if (px2 in 0 until w && py2 in 0 until h && isWhite(px[py2 * w + px2])) { hit = true; break }
                }
                if (hit) { miss = 0; lastHit = d } else { miss++; if (miss > 3) break }
                d += 1f
            }
            val wl = lastHit - r * 1.5f

            whiteLen[i] = wl
            score[i] = wl
        }

        var bi = 0
        for (i in 1 until steps) if (score[i] > score[bi]) bi = i
        val best = score[bi]
        if (best < r * 6f) return null       // لا توجد عصا / لا يوجد تصويب

        // متوسط الزوايا القريبة من الأفضل لدقة أعلى
        var sx = 0.0
        var sy = 0.0
        var wlSum = 0f
        var n = 0
        for (i in 0 until steps) {
            if (score[i] >= best * 0.97f) {
                val a = i * 2.0 * Math.PI / steps
                sx += cos(a); sy += sin(a)
                wlSum += whiteLen[i]; n++
            }
        }
        val ang = atan2(sy, sx).toFloat()
        val lineLen = wlSum / max(n, 1)
        val ux = cos(ang)
        val uy = sin(ang)
        // الخط الأبيض ينتهي عند الحلقة الشبحية؛ مركزها بعد نهاية الخط بنحو نصف قطر
        val lastHit = lineLen + r * 1.5f
        val contact = if (lineLen > r * 3f)
            findContact(px, w, h, tb, r, cx + ux * (lastHit + r), cy + uy * (lastHit + r), cx, cy, ux, uy)
        else null
        return Detection(cx, cy, ang, r, lineLen, TableBox(tb[0], tb[1], tb[2], tb[3]), tw, contact)
    }
}
